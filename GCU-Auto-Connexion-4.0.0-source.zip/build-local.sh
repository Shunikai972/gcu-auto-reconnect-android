#!/usr/bin/env bash
set -euo pipefail

: "${ANDROID_JAR:?Définir ANDROID_JAR}"
: "${AAPT2:?Définir AAPT2}"
: "${R8_JAR:?Définir R8_JAR}"
: "${ZIPALIGN:?Définir ZIPALIGN}"
: "${APKSIGNER_JAR:?Définir APKSIGNER_JAR}"

ROOT="$(cd "$(dirname "$0")" && pwd)"
BUILD="$ROOT/build-local"
OUT="$ROOT/GCU-Auto-Connexion-4.0.0.apk"
STOREPASS="${STOREPASS:-changeit-local-only}"
rm -rf "$BUILD"
mkdir -p "$BUILD/compiled" "$BUILD/classes" "$BUILD/dex"

"$AAPT2" compile --dir "$ROOT/app/src/main/res" -o "$BUILD/compiled"
"$AAPT2" link -I "$ANDROID_JAR" \
  --manifest "$ROOT/app/src/main/AndroidManifest.xml" \
  --min-sdk-version 23 --target-sdk-version 29 \
  --version-code 40000 --version-name 4.0.0 --auto-add-overlay \
  -o "$BUILD/base.apk" "$BUILD/compiled"/*.flat

find "$ROOT/app/src/main/java" -name '*.java' -print0 | xargs -0 javac \
  -encoding UTF-8 -source 8 -target 8 -bootclasspath "$ANDROID_JAR" \
  -d "$BUILD/classes"
(cd "$BUILD/classes" && jar cf "$BUILD/program.jar" .)
java -cp "$R8_JAR" com.android.tools.r8.D8 \
  --min-api 23 --lib "$ANDROID_JAR" --output "$BUILD/dex" "$BUILD/program.jar"
cp "$BUILD/base.apk" "$BUILD/with-dex.apk"
(cd "$BUILD/dex" && zip -q -0 "$BUILD/with-dex.apk" classes.dex)
"$ZIPALIGN" -f -p 4 "$BUILD/with-dex.apk" "$BUILD/aligned.apk"

keytool -genkeypair -noprompt -keystore "$BUILD/local-release.p12" -storetype PKCS12 \
  -storepass "$STOREPASS" -keypass "$STOREPASS" -alias gcu-auto \
  -keyalg RSA -keysize 3072 -validity 3650 \
  -dname 'CN=GCU Auto Connexion Local Build, O=Local, C=FR'
java -jar "$APKSIGNER_JAR" sign \
  --ks "$BUILD/local-release.p12" --ks-type PKCS12 --ks-key-alias gcu-auto \
  --ks-pass "pass:$STOREPASS" --key-pass "pass:$STOREPASS" \
  --v1-signing-enabled true --v2-signing-enabled true --v3-signing-enabled true \
  --out "$OUT" "$BUILD/aligned.apk"
java -jar "$APKSIGNER_JAR" verify --verbose "$OUT"
echo "Créé : $OUT"
