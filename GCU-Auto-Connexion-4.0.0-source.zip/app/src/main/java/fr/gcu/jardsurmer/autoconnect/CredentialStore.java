package fr.gcu.jardsurmer.autoconnect;

import android.content.Context;
import android.content.SharedPreferences;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;

final class CredentialStore {
    private static final String PREFS = "gcu_secure_credentials_v4";
    private static final String DATA = "encrypted_data";
    private static final String ALIAS = "fr.gcu.jardsurmer.autoconnect.credentials.v1";
    private static final String ANDROID_KEY_STORE = "AndroidKeyStore";

    private CredentialStore() {}

    static void save(Context context, Credentials credentials) throws Exception {
        if (credentials == null || !credentials.isComplete()) {
            throw new IllegalArgumentException("Identifiants incomplets");
        }
        byte[] plain = serialize(credentials);
        SecretKey key = getOrCreateKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] encrypted = cipher.doFinal(plain);
        byte[] iv = cipher.getIV();

        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream output = new DataOutputStream(bytes);
        output.writeInt(iv.length);
        output.write(iv);
        output.writeInt(encrypted.length);
        output.write(encrypted);
        output.close();

        String encoded = Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP);
        boolean committed = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString(DATA, encoded).commit();
        if (!committed) throw new IllegalStateException("Enregistrement impossible");
    }

    static Credentials load(Context context) throws Exception {
        SharedPreferences preferences = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String encoded = preferences.getString(DATA, null);
        if (encoded == null || encoded.isEmpty()) return null;

        byte[] packed = Base64.decode(encoded, Base64.NO_WRAP);
        DataInputStream input = new DataInputStream(new ByteArrayInputStream(packed));
        int ivLength = input.readInt();
        if (ivLength < 8 || ivLength > 32) throw new IllegalStateException("Données chiffrées invalides");
        byte[] iv = new byte[ivLength];
        input.readFully(iv);
        int dataLength = input.readInt();
        if (dataLength < 1 || dataLength > 1024 * 1024) throw new IllegalStateException("Données chiffrées invalides");
        byte[] encrypted = new byte[dataLength];
        input.readFully(encrypted);
        input.close();

        KeyStore store = KeyStore.getInstance(ANDROID_KEY_STORE);
        store.load(null);
        SecretKey key = (SecretKey) store.getKey(ALIAS, null);
        if (key == null) throw new IllegalStateException("Clé de chiffrement absente");

        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        return deserialize(cipher.doFinal(encrypted));
    }

    static void clear(Context context) {
        try {
            context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().clear().commit();
        } catch (Throwable ignored) {}
        try {
            KeyStore store = KeyStore.getInstance(ANDROID_KEY_STORE);
            store.load(null);
            if (store.containsAlias(ALIAS)) store.deleteEntry(ALIAS);
        } catch (Throwable ignored) {}
    }

    private static SecretKey getOrCreateKey() throws Exception {
        KeyStore store = KeyStore.getInstance(ANDROID_KEY_STORE);
        store.load(null);
        SecretKey existing = (SecretKey) store.getKey(ALIAS, null);
        if (existing != null) return existing;

        KeyGenerator generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEY_STORE);
        KeyGenParameterSpec spec = new KeyGenParameterSpec.Builder(
                ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build();
        generator.init(spec);
        return generator.generateKey();
    }

    private static byte[] serialize(Credentials credentials) throws Exception {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        DataOutputStream output = new DataOutputStream(bytes);
        writeUtf8(output, credentials.username);
        writeUtf8(output, credentials.password);
        output.close();
        return bytes.toByteArray();
    }

    private static Credentials deserialize(byte[] data) throws Exception {
        DataInputStream input = new DataInputStream(new ByteArrayInputStream(data));
        String username = readUtf8(input);
        String password = readUtf8(input);
        input.close();
        return new Credentials(username, password);
    }

    private static void writeUtf8(DataOutputStream output, String value) throws Exception {
        byte[] bytes = (value == null ? "" : value).getBytes(StandardCharsets.UTF_8);
        output.writeInt(bytes.length);
        output.write(bytes);
    }

    private static String readUtf8(DataInputStream input) throws Exception {
        int length = input.readInt();
        if (length < 0 || length > 1024 * 1024) throw new IllegalStateException("Données invalides");
        byte[] bytes = new byte[length];
        input.readFully(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }
}
