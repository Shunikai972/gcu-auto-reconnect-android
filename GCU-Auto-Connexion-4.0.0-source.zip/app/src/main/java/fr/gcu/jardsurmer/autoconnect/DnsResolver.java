package fr.gcu.jardsurmer.autoconnect;

import android.content.Context;
import android.net.Network;

import java.io.ByteArrayOutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

final class DnsResolver {
    private static final SecureRandom RANDOM = new SecureRandom();
    private final Context context;
    private final Network network;

    DnsResolver(Context context, Network network) {
        this.context = context.getApplicationContext();
        this.network = network;
    }

    List<InetAddress> resolve(String host) throws Exception {
        LinkedHashSet<InetAddress> addresses = new LinkedHashSet<InetAddress>();
        try {
            InetAddress[] nativeAnswers = network.getAllByName(host);
            for (InetAddress answer : nativeAnswers) {
                if (answer instanceof Inet4Address) addresses.add(answer);
            }
        } catch (Throwable ignored) {}

        if (addresses.isEmpty()) {
            for (InetAddress dnsServer : NetworkInspector.dnsServers(context, network)) {
                try {
                    addresses.addAll(queryA(host, dnsServer));
                } catch (Throwable ignored) {}
                if (!addresses.isEmpty()) break;
            }
        }
        if (addresses.isEmpty()) throw new java.net.UnknownHostException("Adresse introuvable pour " + host);
        return new ArrayList<InetAddress>(addresses);
    }

    private List<InetAddress> queryA(String host, InetAddress dnsServer) throws Exception {
        int id = RANDOM.nextInt(65536);
        byte[] query = buildQuery(host, id);
        DatagramSocket socket = new DatagramSocket(null);
        try {
            socket.setReuseAddress(true);
            socket.bind(new InetSocketAddress(0));
            network.bindSocket(socket);
            socket.setSoTimeout(3500);
            socket.send(new DatagramPacket(query, query.length, dnsServer, 53));
            byte[] buffer = new byte[4096];
            DatagramPacket incoming = new DatagramPacket(buffer, buffer.length);
            socket.receive(incoming);
            return parseResponse(buffer, incoming.getLength(), id);
        } finally {
            socket.close();
        }
    }

    private static byte[] buildQuery(String host, int id) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        writeU16(out, id);
        writeU16(out, 0x0100);
        writeU16(out, 1);
        writeU16(out, 0);
        writeU16(out, 0);
        writeU16(out, 0);
        for (String label : host.split("\\.")) {
            byte[] bytes = label.getBytes(StandardCharsets.US_ASCII);
            if (bytes.length == 0 || bytes.length > 63) throw new IllegalArgumentException("Nom DNS invalide");
            out.write(bytes.length);
            out.write(bytes);
        }
        out.write(0);
        writeU16(out, 1);
        writeU16(out, 1);
        return out.toByteArray();
    }

    private static List<InetAddress> parseResponse(byte[] data, int length, int expectedId) throws Exception {
        if (length < 12 || u16(data, 0) != expectedId) throw new IllegalArgumentException("Réponse DNS invalide");
        if ((u16(data, 2) & 0x0F) != 0) throw new IllegalArgumentException("Erreur DNS");
        int qd = u16(data, 4);
        int total = u16(data, 6) + u16(data, 8) + u16(data, 10);
        int offset = 12;
        for (int i = 0; i < qd; i++) {
            offset = skipName(data, length, offset);
            if (offset + 4 > length) throw new IllegalArgumentException("DNS tronqué");
            offset += 4;
        }
        Set<InetAddress> answers = new LinkedHashSet<InetAddress>();
        for (int i = 0; i < total; i++) {
            offset = skipName(data, length, offset);
            if (offset + 10 > length) throw new IllegalArgumentException("DNS tronqué");
            int type = u16(data, offset);
            int clazz = u16(data, offset + 2);
            int rdLength = u16(data, offset + 8);
            offset += 10;
            if (offset + rdLength > length) throw new IllegalArgumentException("DNS tronqué");
            if (type == 1 && clazz == 1 && rdLength == 4) {
                answers.add(InetAddress.getByAddress(new byte[]{data[offset], data[offset + 1], data[offset + 2], data[offset + 3]}));
            }
            offset += rdLength;
        }
        return new ArrayList<InetAddress>(answers);
    }

    private static int skipName(byte[] data, int length, int offset) {
        int guard = 0;
        while (offset < length && guard++ < 128) {
            int value = data[offset] & 0xFF;
            if (value == 0) return offset + 1;
            if ((value & 0xC0) == 0xC0) return offset + 2;
            offset++;
            if (offset + value > length) throw new IllegalArgumentException("Nom DNS tronqué");
            offset += value;
        }
        throw new IllegalArgumentException("Nom DNS invalide");
    }

    private static void writeU16(ByteArrayOutputStream out, int value) {
        out.write((value >>> 8) & 0xFF);
        out.write(value & 0xFF);
    }

    private static int u16(byte[] data, int offset) {
        return ((data[offset] & 0xFF) << 8) | (data[offset + 1] & 0xFF);
    }
}
