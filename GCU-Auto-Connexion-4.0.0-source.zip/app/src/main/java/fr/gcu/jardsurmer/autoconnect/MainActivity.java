package fr.gcu.jardsurmer.autoconnect;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public final class MainActivity extends Activity {
    private EditText username;
    private EditText password;
    private Switch autoSwitch;
    private TextView status;
    private final Handler handler = new Handler();
    private final Runnable statusRefresh = new Runnable() {
        @Override public void run() {
            refreshStatus();
            handler.postDelayed(this, 2000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildContent());
        loadCredentials();
        autoSwitch.setChecked(AppState.isEnabled(this));
        installListeners();
        requestNotificationPermission();
        refreshStatus();
    }

    private View buildContent() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(Color.rgb(245, 247, 248));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setGravity(Gravity.CENTER);
        header.setPadding(dp(18), dp(22), dp(18), dp(22));
        GradientDrawable headerBg = new GradientDrawable();
        headerBg.setColor(Color.rgb(11, 107, 87));
        headerBg.setCornerRadius(dp(18));
        header.setBackground(headerBg);

        TextView title = new TextView(this);
        title.setText("Wi-Fi GCU Jard-sur-Mer");
        title.setTextColor(Color.WHITE);
        title.setTextSize(27);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        header.addView(title, matchWrap());

        TextView subtitle = new TextView(this);
        subtitle.setText("Connexion automatique au portail ALCASAR\nContrôle immédiat puis toutes les 10 minutes");
        subtitle.setTextColor(Color.WHITE);
        subtitle.setTextSize(16);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, dp(8), 0, 0);
        header.addView(subtitle, matchWrap());
        root.addView(header, matchWrapWithBottom(dp(16)));

        LinearLayout statusCard = card();
        TextView statusTitle = label("État de la connexion");
        statusCard.addView(statusTitle, matchWrap());
        status = new TextView(this);
        status.setTextSize(17);
        status.setTextColor(Color.rgb(35, 45, 50));
        status.setPadding(0, dp(8), 0, 0);
        statusCard.addView(status, matchWrap());
        root.addView(statusCard, matchWrapWithBottom(dp(16)));

        LinearLayout credentialsCard = card();
        credentialsCard.addView(label("Vos identifiants"), matchWrap());
        TextView privacy = new TextView(this);
        privacy.setText("Ils sont chiffrés avec Android Keystore et restent sur cet appareil.");
        privacy.setTextSize(15);
        privacy.setTextColor(Color.DKGRAY);
        privacy.setPadding(0, dp(4), 0, dp(12));
        credentialsCard.addView(privacy, matchWrap());

        credentialsCard.addView(fieldLabel("Identifiant"), matchWrap());
        username = new EditText(this);
        username.setSingleLine(true);
        username.setTextSize(19);
        username.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        credentialsCard.addView(username, matchHeight(dp(58)));

        TextView passwordLabel = fieldLabel("Mot de passe");
        passwordLabel.setPadding(0, dp(12), 0, dp(4));
        credentialsCard.addView(passwordLabel, matchWrap());
        password = new EditText(this);
        password.setSingleLine(true);
        password.setTextSize(19);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        credentialsCard.addView(password, matchHeight(dp(58)));

        CheckBox showPassword = new CheckBox(this);
        showPassword.setText("Afficher le mot de passe");
        showPassword.setTextSize(16);
        showPassword.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int position = password.getSelectionStart();
                password.setInputType(InputType.TYPE_CLASS_TEXT | (isChecked
                        ? InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                        : InputType.TYPE_TEXT_VARIATION_PASSWORD));
                password.setSelection(Math.max(0, Math.min(position, password.length())));
            }
        });
        credentialsCard.addView(showPassword, matchWrap());

        Button save = button("Enregistrer les identifiants");
        save.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) { saveCredentials(true); }
        });
        credentialsCard.addView(save, matchHeightWithTop(dp(56), dp(10)));

        Button connect = button("Se connecter maintenant");
        connect.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                if (saveCredentials(false)) {
                    AppState.setStatus(MainActivity.this, "Connexion manuelle demandée…");
                    AutoConnectService.connectNow(MainActivity.this);
                    refreshStatus();
                }
            }
        });
        credentialsCard.addView(connect, matchHeightWithTop(dp(56), dp(10)));
        root.addView(credentialsCard, matchWrapWithBottom(dp(16)));

        LinearLayout autoCard = card();
        autoCard.addView(label("Reconnexion automatique"), matchWrap());
        TextView explanation = new TextView(this);
        explanation.setText("Vous pouvez l’activer avant d’arriver au camping. Sans Wi-Fi GCU, l’application attend simplement sans planter.");
        explanation.setTextSize(15);
        explanation.setTextColor(Color.DKGRAY);
        explanation.setPadding(0, dp(4), 0, dp(8));
        autoCard.addView(explanation, matchWrap());
        autoSwitch = new Switch(this);
        autoSwitch.setText("Auto-reconnexion activée");
        autoSwitch.setTextSize(18);
        autoSwitch.setPadding(0, dp(6), 0, dp(6));
        autoCard.addView(autoSwitch, matchWrap());

        Button clear = button("Effacer les identifiants");
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View view) {
                AppState.setEnabled(MainActivity.this, false);
                stopService(new Intent(MainActivity.this, AutoConnectService.class));
                CredentialStore.clear(MainActivity.this);
                username.setText("");
                password.setText("");
                autoSwitch.setChecked(false);
                AppState.setStatus(MainActivity.this, "Identifiants effacés.");
                refreshStatus();
            }
        });
        autoCard.addView(clear, matchHeightWithTop(dp(52), dp(12)));
        root.addView(autoCard, matchWrap());
        return scroll;
    }

    private void installListeners() {
        autoSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton buttonView, boolean enabled) {
                if (enabled) {
                    if (!saveCredentials(false)) {
                        autoSwitch.setOnCheckedChangeListener(null);
                        autoSwitch.setChecked(false);
                        installListeners();
                        return;
                    }
                    AppState.setEnabled(MainActivity.this, true);
                    AppState.setStatus(MainActivity.this, "Auto-reconnexion activée. Recherche du Wi-Fi GCU…");
                    AutoConnectService.startAuto(MainActivity.this);
                } else {
                    AppState.setEnabled(MainActivity.this, false);
                    AppState.setStatus(MainActivity.this, "Auto-reconnexion désactivée.");
                    stopService(new Intent(MainActivity.this, AutoConnectService.class));
                }
                refreshStatus();
            }
        });
    }

    private boolean saveCredentials(boolean showConfirmation) {
        Credentials credentials = new Credentials(username.getText().toString().trim(), password.getText().toString());
        if (!credentials.isComplete()) {
            Toast.makeText(this, "Saisissez l’identifiant et le mot de passe.", Toast.LENGTH_LONG).show();
            return false;
        }
        try {
            CredentialStore.save(this, credentials);
            if (showConfirmation) Toast.makeText(this, "Identifiants enregistrés et chiffrés.", Toast.LENGTH_SHORT).show();
            return true;
        } catch (Throwable throwable) {
            Toast.makeText(this, "Enregistrement impossible : " + throwable.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void loadCredentials() {
        try {
            Credentials credentials = CredentialStore.load(this);
            if (credentials != null) {
                username.setText(credentials.username);
                password.setText(credentials.password);
            }
        } catch (Throwable throwable) {
            AppState.setStatus(this, "Les anciens identifiants chiffrés sont illisibles. Enregistrez-les de nouveau.");
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 33);
        }
    }

    private void refreshStatus() {
        if (status != null) status.setText(AppState.statusText(this));
    }

    @Override protected void onResume() {
        super.onResume();
        handler.removeCallbacks(statusRefresh);
        handler.post(statusRefresh);
    }

    @Override protected void onPause() {
        handler.removeCallbacks(statusRefresh);
        super.onPause();
    }

    private LinearLayout card() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(dp(18), dp(18), dp(18), dp(18));
        GradientDrawable background = new GradientDrawable();
        background.setColor(Color.WHITE);
        background.setCornerRadius(dp(16));
        background.setStroke(dp(1), Color.rgb(205, 214, 218));
        layout.setBackground(background);
        return layout;
    }

    private TextView label(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(21);
        view.setTextColor(Color.rgb(30, 40, 45));
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return view;
    }

    private TextView fieldLabel(String value) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(16);
        view.setTextColor(Color.rgb(35, 45, 50));
        view.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        view.setPadding(0, 0, 0, dp(4));
        return view;
    }

    private Button button(String value) {
        Button button = new Button(this);
        button.setText(value);
        button.setTextSize(17);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
    }

    private LinearLayout.LayoutParams matchWrapWithBottom(int bottom) {
        LinearLayout.LayoutParams params = matchWrap();
        params.bottomMargin = bottom;
        return params;
    }

    private LinearLayout.LayoutParams matchHeight(int height) {
        return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, height);
    }

    private LinearLayout.LayoutParams matchHeightWithTop(int height, int top) {
        LinearLayout.LayoutParams params = matchHeight(height);
        params.topMargin = top;
        return params;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
