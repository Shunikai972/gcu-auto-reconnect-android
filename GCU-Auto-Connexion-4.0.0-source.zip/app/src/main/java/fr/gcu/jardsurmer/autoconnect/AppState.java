package fr.gcu.jardsurmer.autoconnect;

import android.content.Context;
import android.content.SharedPreferences;

import java.text.DateFormat;
import java.util.Date;

final class AppState {
    private static final String PREFS = "gcu_auto_state_v4";
    private static final String ENABLED = "enabled";
    private static final String STATUS = "status";
    private static final String STATUS_TIME = "status_time";
    private static final String SERVICE_RUNNING = "service_running";

    private AppState() {}

    private static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean isEnabled(Context context) {
        return prefs(context).getBoolean(ENABLED, false);
    }

    static void setEnabled(Context context, boolean enabled) {
        prefs(context).edit().putBoolean(ENABLED, enabled).apply();
    }

    static void setServiceRunning(Context context, boolean running) {
        prefs(context).edit().putBoolean(SERVICE_RUNNING, running).apply();
    }

    static boolean isServiceRunning(Context context) {
        return prefs(context).getBoolean(SERVICE_RUNNING, false);
    }

    static void setStatus(Context context, String status) {
        prefs(context).edit()
                .putString(STATUS, status == null ? "" : status)
                .putLong(STATUS_TIME, System.currentTimeMillis())
                .apply();
    }

    static String statusText(Context context) {
        SharedPreferences p = prefs(context);
        String status = p.getString(STATUS, "");
        long time = p.getLong(STATUS_TIME, 0L);
        if (status == null || status.trim().isEmpty()) {
            status = isEnabled(context)
                    ? "Auto-reconnexion activée. En attente du Wi-Fi GCU."
                    : "Enregistrez vos identifiants, puis activez l’auto-reconnexion.";
        }
        StringBuilder out = new StringBuilder(status.trim());
        if (time > 0L) {
            DateFormat format = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT);
            out.append("\nDernière mise à jour : ").append(format.format(new Date(time)));
        }
        if (isEnabled(context)) {
            out.append(isServiceRunning(context)
                    ? "\nService automatique actif."
                    : "\nService arrêté : ouvrez l’application et réactivez le bouton.");
        }
        return out.toString();
    }
}
