package fr.gcu.jardsurmer.autoconnect;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class AutoConnectService extends Service {
    static final String ACTION_START_AUTO = "fr.gcu.jardsurmer.autoconnect.START_AUTO";
    static final String ACTION_CONNECT_NOW = "fr.gcu.jardsurmer.autoconnect.CONNECT_NOW";
    private static final String CHANNEL_ID = "gcu_auto_connection";
    private static final int NOTIFICATION_ID = 4100;

    private final AtomicBoolean attemptRunning = new AtomicBoolean(false);
    private ScheduledExecutorService executor;
    private ConnectivityManager connectivityManager;
    private ConnectivityManager.NetworkCallback networkCallback;

    static void startAuto(Context context) {
        Intent intent = new Intent(context, AutoConnectService.class).setAction(ACTION_START_AUTO);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent);
        else context.startService(intent);
    }

    static void connectNow(Context context) {
        Intent intent = new Intent(context, AutoConnectService.class).setAction(ACTION_CONNECT_NOW);
        if (Build.VERSION.SDK_INT >= 26) context.startForegroundService(intent);
        else context.startService(intent);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID, buildNotification("Initialisation…"));
        AppState.setServiceRunning(this, true);

        executor = Executors.newSingleThreadScheduledExecutor();
        connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        registerWifiCallback();
        executor.scheduleAtFixedRate(new Runnable() {
            @Override public void run() {
                if (AppState.isEnabled(AutoConnectService.this)) triggerAttempt(false, "contrôle périodique");
            }
        }, 10, 10, TimeUnit.MINUTES);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? null : intent.getAction();
        if (ACTION_START_AUTO.equals(action)) {
            AppState.setEnabled(this, true);
            setStatus("Auto-reconnexion active. Recherche du Wi-Fi GCU…");
            triggerAttempt(false, "activation");
            return START_STICKY;
        }
        if (ACTION_CONNECT_NOW.equals(action)) {
            setStatus("Connexion manuelle en cours…");
            triggerAttempt(true, "demande manuelle");
            return AppState.isEnabled(this) ? START_STICKY : START_NOT_STICKY;
        }
        if (AppState.isEnabled(this)) {
            triggerAttempt(false, "redémarrage du service");
            return START_STICKY;
        }
        stopSelf();
        return START_NOT_STICKY;
    }

    private void registerWifiCallback() {
        if (connectivityManager == null) return;
        try {
            NetworkRequest request = new NetworkRequest.Builder()
                    .addTransportType(android.net.NetworkCapabilities.TRANSPORT_WIFI)
                    .build();
            networkCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) {
                    if (executor != null && AppState.isEnabled(AutoConnectService.this)) {
                        executor.schedule(new Runnable() {
                            @Override public void run() {
                                triggerAttempt(false, "Wi-Fi détecté");
                            }
                        }, 2, TimeUnit.SECONDS);
                    }
                }

                @Override public void onLost(Network network) {
                    if (NetworkInspector.findWifiNetwork(AutoConnectService.this) == null) {
                        setStatus("Wi-Fi absent. L’auto-reconnexion reste active et attend le réseau GCU.");
                    }
                }
            };
            connectivityManager.registerNetworkCallback(request, networkCallback);
        } catch (Throwable ignored) {
            setStatus("Surveillance Wi-Fi limitée. Le contrôle toutes les 10 minutes reste actif.");
        }
    }

    private void triggerAttempt(final boolean oneShot, String reason) {
        if (!attemptRunning.compareAndSet(false, true)) return;
        if (executor == null) {
            attemptRunning.set(false);
            return;
        }
        executor.execute(new Runnable() {
            @Override public void run() {
                PowerManager.WakeLock wakeLock = null;
                try {
                    PowerManager power = (PowerManager) getSystemService(POWER_SERVICE);
                    if (power != null) {
                        wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "GCUAuto:portal-login");
                        wakeLock.acquire(90000L);
                    }
                    Credentials credentials;
                    try {
                        credentials = CredentialStore.load(AutoConnectService.this);
                    } catch (Throwable credentialError) {
                        setStatus("Impossible de lire les identifiants chiffrés. Ouvrez l’application et enregistrez-les de nouveau.");
                        return;
                    }
                    Network wifi = NetworkInspector.findWifiNetwork(AutoConnectService.this);
                    PortalLoginClient.Result result = PortalLoginClient.login(AutoConnectService.this, wifi, credentials);
                    setStatus(result.message);
                } finally {
                    if (wakeLock != null && wakeLock.isHeld()) {
                        try { wakeLock.release(); } catch (Throwable ignored) {}
                    }
                    attemptRunning.set(false);
                    if (oneShot && !AppState.isEnabled(AutoConnectService.this)) stopSelf();
                }
            }
        });
    }

    private void setStatus(String message) {
        AppState.setStatus(this, message);
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager != null) {
            try { manager.notify(NOTIFICATION_ID, buildNotification(message)); }
            catch (Throwable ignored) {}
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager manager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (manager == null) return;
        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "Connexion automatique GCU", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Maintient la reconnexion au portail Wi-Fi GCU.");
        channel.setShowBadge(false);
        manager.createNotificationChannel(channel);
    }

    private Notification buildNotification(String text) {
        Intent open = new Intent(this, MainActivity.class);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent contentIntent = PendingIntent.getActivity(this, 0, open, flags);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        builder.setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("GCU Auto Connexion")
                .setContentText(text == null ? "Service actif" : text)
                .setStyle(new Notification.BigTextStyle().bigText(text == null ? "Service actif" : text))
                .setOngoing(AppState.isEnabled(this))
                .setOnlyAlertOnce(true)
                .setContentIntent(contentIntent)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setVisibility(Notification.VISIBILITY_PRIVATE);
        return builder.build();
    }

    @Override
    public void onDestroy() {
        if (connectivityManager != null && networkCallback != null) {
            try { connectivityManager.unregisterNetworkCallback(networkCallback); } catch (Throwable ignored) {}
        }
        if (executor != null) executor.shutdownNow();
        AppState.setServiceRunning(this, false);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
