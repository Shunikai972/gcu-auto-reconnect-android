package fr.gcu.jardsurmer.autoconnect;

import android.net.Network;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URI;
import java.net.URL;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

final class RawHttpClient {
    private static final int MAX_BODY_BYTES = 2_500_000;
    private final Network network;
    private final DnsResolver resolver;
    private final LinkedHashMap<String, String> cookies = new LinkedHashMap<String, String>();
    private final SSLSocketFactory strictSslFactory;
    private final SSLSocketFactory localSslFactory;

    RawHttpClient(Network network, DnsResolver resolver) throws Exception {
        this.network = network;
        this.resolver = resolver;

        SSLContext strict = SSLContext.getInstance("TLS");
        strict.init(null, null, new SecureRandom());
        strictSslFactory = strict.getSocketFactory();

        TrustManager[] localTrust = new TrustManager[]{new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) {}
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) {}
            @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        }};
        SSLContext local = SSLContext.getInstance("TLS");
        local.init(null, localTrust, new SecureRandom());
        localSslFactory = local.getSocketFactory();
    }

    Response execute(String method, String url, byte[] body, Map<String, String> extraHeaders, int maxRedirects) throws Exception {
        String currentMethod = method == null ? "GET" : method.toUpperCase(Locale.US);
        byte[] currentBody = body;
        String currentUrl = url;
        for (int redirect = 0; redirect <= maxRedirects; redirect++) {
            Response response = executeOnce(currentMethod, currentUrl, currentBody, extraHeaders);
            String location = response.firstHeader("location");
            if (!isRedirect(response.statusCode) || location == null || location.trim().isEmpty() || redirect == maxRedirects) {
                return response;
            }
            String next = new URI(currentUrl).resolve(location.trim()).toString();
            if (response.statusCode == 303 || ((response.statusCode == 301 || response.statusCode == 302) && "POST".equals(currentMethod))) {
                currentMethod = "GET";
                currentBody = null;
            }
            currentUrl = next;
        }
        throw new IOException("Trop de redirections");
    }

    private Response executeOnce(String method, String address, byte[] body, Map<String, String> extraHeaders) throws Exception {
        URL url = new URL(address);
        String scheme = url.getProtocol().toLowerCase(Locale.US);
        if (!"http".equals(scheme) && !"https".equals(scheme)) throw new IOException("Schéma non pris en charge");
        String host = url.getHost();
        int port = url.getPort() > 0 ? url.getPort() : ("https".equals(scheme) ? 443 : 80);
        boolean localController = isLocalController(host);

        List<InetAddress> addresses = isNumericAddress(host)
                ? Collections.singletonList(InetAddress.getByName(host))
                : resolver.resolve(host);
        Exception last = null;
        for (InetAddress ip : addresses) {
            Socket socket = null;
            try {
                Socket raw = network.getSocketFactory().createSocket();
                raw.connect(new InetSocketAddress(ip, port), 8000);
                raw.setSoTimeout(10000);
                if ("https".equals(scheme)) {
                    SSLSocketFactory factory = localController ? localSslFactory : strictSslFactory;
                    SSLSocket ssl = (SSLSocket) factory.createSocket(raw, host, port, true);
                    ssl.setUseClientMode(true);
                    ssl.startHandshake();
                    if (!localController) {
                        HostnameVerifier verifier = HttpsURLConnection.getDefaultHostnameVerifier();
                        SSLSession session = ssl.getSession();
                        if (!verifier.verify(host, session)) {
                            try { ssl.close(); } catch (Throwable ignored) {}
                            throw new javax.net.ssl.SSLPeerUnverifiedException("Certificat HTTPS invalide");
                        }
                    }
                    socket = ssl;
                } else {
                    socket = raw;
                }
                Response response = sendAndRead(socket, method, url, port, body, extraHeaders);
                updateCookies(response.headers);
                return response;
            } catch (Exception exception) {
                last = exception;
                if (socket != null) try { socket.close(); } catch (Throwable ignored) {}
            }
        }
        throw last == null ? new IOException("Connexion impossible") : last;
    }

    private Response sendAndRead(Socket socket, String method, URL url, int port, byte[] body,
                                 Map<String, String> extraHeaders) throws Exception {
        try {
            String path = url.getFile();
            if (path == null || path.isEmpty()) path = "/";
            String hostHeader = url.getHost();
            boolean defaultPort = ("http".equalsIgnoreCase(url.getProtocol()) && port == 80)
                    || ("https".equalsIgnoreCase(url.getProtocol()) && port == 443);
            if (!defaultPort) hostHeader += ":" + port;

            LinkedHashMap<String, String> headers = new LinkedHashMap<String, String>();
            headers.put("Host", hostHeader);
            headers.put("User-Agent", "Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 GCU-Auto-Connexion/4.0");
            headers.put("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
            headers.put("Accept-Language", "fr-FR,fr;q=0.9,en;q=0.5");
            headers.put("Accept-Encoding", "gzip");
            headers.put("Cache-Control", "no-cache");
            headers.put("Connection", "close");
            String cookieHeader = cookieHeader();
            if (!cookieHeader.isEmpty()) headers.put("Cookie", cookieHeader);
            if (extraHeaders != null) headers.putAll(extraHeaders);
            if (body != null) {
                if (!containsHeader(headers, "Content-Type")) headers.put("Content-Type", "application/x-www-form-urlencoded");
                headers.put("Content-Length", String.valueOf(body.length));
            }

            OutputStream out = socket.getOutputStream();
            StringBuilder request = new StringBuilder();
            request.append(method).append(' ').append(path).append(" HTTP/1.1\r\n");
            for (Map.Entry<String, String> header : headers.entrySet()) {
                request.append(header.getKey()).append(": ").append(header.getValue()).append("\r\n");
            }
            request.append("\r\n");
            out.write(request.toString().getBytes(StandardCharsets.ISO_8859_1));
            if (body != null) out.write(body);
            out.flush();

            BufferedInputStream in = new BufferedInputStream(socket.getInputStream());
            String statusLine = readLine(in, 16384);
            if (statusLine == null || !statusLine.startsWith("HTTP/")) throw new IOException("Réponse HTTP invalide");
            String[] statusParts = statusLine.split(" ", 3);
            int status = statusParts.length > 1 ? Integer.parseInt(statusParts[1]) : 0;
            String reason = statusParts.length > 2 ? statusParts[2] : "";

            LinkedHashMap<String, List<String>> responseHeaders = new LinkedHashMap<String, List<String>>();
            while (true) {
                String line = readLine(in, 65536);
                if (line == null || line.isEmpty()) break;
                int colon = line.indexOf(':');
                if (colon <= 0) continue;
                String name = line.substring(0, colon).trim().toLowerCase(Locale.US);
                String value = line.substring(colon + 1).trim();
                List<String> values = responseHeaders.get(name);
                if (values == null) {
                    values = new ArrayList<String>();
                    responseHeaders.put(name, values);
                }
                values.add(value);
            }

            byte[] rawBody;
            String transfer = first(responseHeaders, "transfer-encoding");
            String contentLength = first(responseHeaders, "content-length");
            if (transfer != null && transfer.toLowerCase(Locale.US).contains("chunked")) {
                rawBody = readChunked(in, MAX_BODY_BYTES);
            } else if (contentLength != null) {
                int length;
                try { length = Integer.parseInt(contentLength.trim()); }
                catch (NumberFormatException ignored) { length = MAX_BODY_BYTES; }
                rawBody = readFixed(in, Math.min(length, MAX_BODY_BYTES));
            } else {
                rawBody = readUntilEof(in, MAX_BODY_BYTES);
            }
            String encoding = first(responseHeaders, "content-encoding");
            if (encoding != null && encoding.toLowerCase(Locale.US).contains("gzip")) {
                rawBody = gunzip(rawBody, MAX_BODY_BYTES);
            }
            return new Response(url.toString(), status, reason, responseHeaders, rawBody);
        } finally {
            try { socket.close(); } catch (Throwable ignored) {}
        }
    }

    private void updateCookies(Map<String, List<String>> headers) {
        List<String> values = headers.get("set-cookie");
        if (values == null) return;
        for (String value : values) {
            if (value == null) continue;
            String pair = value.split(";", 2)[0];
            int equals = pair.indexOf('=');
            if (equals <= 0) continue;
            cookies.put(pair.substring(0, equals).trim(), pair.substring(equals + 1).trim());
        }
    }

    private String cookieHeader() {
        StringBuilder out = new StringBuilder();
        for (Map.Entry<String, String> entry : cookies.entrySet()) {
            if (out.length() > 0) out.append("; ");
            out.append(entry.getKey()).append('=').append(entry.getValue());
        }
        return out.toString();
    }

    private static boolean isRedirect(int status) {
        return status == 301 || status == 302 || status == 303 || status == 307 || status == 308;
    }

    private static boolean isLocalController(String host) {
        return "192.168.182.1".equals(host) || "1.0.0.1".equals(host) || host.endsWith(".localdomain");
    }

    private static boolean isNumericAddress(String host) {
        return host.matches("[0-9.]+") || host.contains(":");
    }

    private static boolean containsHeader(Map<String, String> headers, String name) {
        for (String key : headers.keySet()) if (name.equalsIgnoreCase(key)) return true;
        return false;
    }

    private static String first(Map<String, List<String>> headers, String name) {
        List<String> values = headers.get(name.toLowerCase(Locale.US));
        return values == null || values.isEmpty() ? null : values.get(0);
    }

    private static String readLine(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        int previous = -1;
        while (out.size() < max) {
            int current = in.read();
            if (current < 0) {
                if (out.size() == 0) return null;
                break;
            }
            if (previous == '\r' && current == '\n') {
                byte[] bytes = out.toByteArray();
                return new String(bytes, 0, Math.max(0, bytes.length - 1), StandardCharsets.ISO_8859_1);
            }
            out.write(current);
            previous = current;
        }
        if (out.size() >= max) throw new IOException("Ligne HTTP trop longue");
        return new String(out.toByteArray(), StandardCharsets.ISO_8859_1);
    }

    private static byte[] readChunked(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        while (out.size() < max) {
            String line = readLine(in, 1024);
            if (line == null) throw new EOFException("Flux interrompu");
            int semicolon = line.indexOf(';');
            String sizeText = semicolon >= 0 ? line.substring(0, semicolon) : line;
            int size = Integer.parseInt(sizeText.trim(), 16);
            if (size == 0) {
                while (true) {
                    String trailer = readLine(in, 65536);
                    if (trailer == null || trailer.isEmpty()) break;
                }
                break;
            }
            byte[] chunk = readFixed(in, size);
            int allowed = Math.min(chunk.length, max - out.size());
            out.write(chunk, 0, allowed);
            String end = readLine(in, 4);
            if (end == null || !end.isEmpty()) throw new IOException("Bloc HTTP invalide");
            if (allowed < chunk.length) break;
        }
        return out.toByteArray();
    }

    private static byte[] readFixed(InputStream in, int length) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(0, length));
        byte[] buffer = new byte[8192];
        int remaining = length;
        while (remaining > 0) {
            int read = in.read(buffer, 0, Math.min(buffer.length, remaining));
            if (read < 0) break;
            out.write(buffer, 0, read);
            remaining -= read;
        }
        return out.toByteArray();
    }

    private static byte[] readUntilEof(InputStream in, int max) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        while (out.size() < max) {
            int read = in.read(buffer, 0, Math.min(buffer.length, max - out.size()));
            if (read < 0) break;
            out.write(buffer, 0, read);
        }
        return out.toByteArray();
    }

    private static byte[] gunzip(byte[] compressed, int max) throws IOException {
        GZIPInputStream gzip = new GZIPInputStream(new ByteArrayInputStream(compressed));
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192];
            while (out.size() < max) {
                int read = gzip.read(buffer, 0, Math.min(buffer.length, max - out.size()));
                if (read < 0) break;
                out.write(buffer, 0, read);
            }
            return out.toByteArray();
        } finally {
            gzip.close();
        }
    }

    static final class Response {
        final String url;
        final int statusCode;
        final String reason;
        final Map<String, List<String>> headers;
        final byte[] body;

        Response(String url, int statusCode, String reason, Map<String, List<String>> headers, byte[] body) {
            this.url = url;
            this.statusCode = statusCode;
            this.reason = reason;
            this.headers = headers;
            this.body = body;
        }

        String firstHeader(String name) { return RawHttpClient.first(headers, name); }

        String bodyText() {
            String contentType = firstHeader("content-type");
            Charset charset = StandardCharsets.UTF_8;
            if (contentType != null) {
                java.util.regex.Matcher matcher = java.util.regex.Pattern.compile("(?i)charset=([^;\\s]+)").matcher(contentType);
                if (matcher.find()) {
                    try { charset = Charset.forName(matcher.group(1).replace("\"", "").trim()); }
                    catch (Throwable ignored) {}
                }
            }
            return new String(body, charset);
        }
    }
}
