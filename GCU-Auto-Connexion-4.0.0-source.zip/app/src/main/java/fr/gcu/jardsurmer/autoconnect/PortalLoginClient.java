package fr.gcu.jardsurmer.autoconnect;

import android.content.Context;
import android.net.Network;

import java.net.URI;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

final class PortalLoginClient {
    private static final String PRELOGIN = "http://192.168.182.1:3990/prelogin";
    private static final String CHECK_URL = "http://connectivitycheck.gstatic.com/generate_204";
    private static final String PORTAL_HOST = "jard-sur-mer.gcuf.fr";

    private PortalLoginClient() {}

    static Result login(Context context, Network network, Credentials credentials) {
        if (network == null) return Result.waiting("Aucun Wi-Fi actif. En attente du Wi-Fi GCU.");
        if (!NetworkInspector.isGcuCandidate(context, network)) {
            return Result.waiting("Wi-Fi non GCU détecté. En attente du réseau 192.168.182.x.");
        }
        if (credentials == null || !credentials.isComplete()) {
            return Result.failure("Identifiants absents. Ouvrez l’application pour les enregistrer.");
        }

        try {
            DnsResolver resolver = new DnsResolver(context, network);
            RawHttpClient client = new RawHttpClient(network, resolver);

            if (isOnline(client)) {
                return Result.success("Connexion Internet déjà active sur le Wi-Fi GCU.");
            }

            RawHttpClient.Response prelogin = client.execute("GET", PRELOGIN, null, null, 0);
            String portalUrl = prelogin.firstHeader("location");
            if (portalUrl == null || portalUrl.trim().isEmpty()) {
                return Result.failure("Le contrôleur GCU n’a pas fourni l’adresse du portail.");
            }
            validatePortalUrl(portalUrl, false);

            RawHttpClient.Response portal = client.execute("GET", portalUrl, null, null, 0);
            if (portal.statusCode != 200) {
                return Result.failure("Le portail GCU a répondu avec le code " + portal.statusCode + ".");
            }
            HtmlFormParser.Form form = HtmlFormParser.parseBest(portalUrl, portal.bodyText());
            validatePortalUrl(form.action, false);
            if (!"POST".equalsIgnoreCase(form.method)) {
                return Result.failure("Le formulaire GCU n’utilise pas la méthode attendue.");
            }

            byte[] body = form.buildBody(credentials.username, credentials.password);
            Map<String, String> headers = new LinkedHashMap<String, String>();
            headers.put("Content-Type", "application/x-www-form-urlencoded");
            headers.put("Referer", portalUrl);
            RawHttpClient.Response authentication = client.execute("POST", form.action, body, headers, 0);
            String logonUrl = authentication.firstHeader("location");
            if (logonUrl == null || logonUrl.trim().isEmpty()) {
                return Result.failure("Le portail n’a pas lancé l’étape de connexion ALCASAR.");
            }
            validatePortalUrl(logonUrl, true);

            RawHttpClient.Response logon = client.execute("GET", logonUrl, null, null, 4);
            if (isOnline(client)) {
                return Result.success("Connexion GCU réussie. Internet est disponible.");
            }

            String finalUrl = logon.url == null ? "" : logon.url.toLowerCase(Locale.US);
            if (finalUrl.contains("res=success") || finalUrl.contains("res=already")) {
                return Result.success("Le portail a accepté la connexion. Validation Internet en cours.");
            }
            String page = logon.bodyText().toLowerCase(Locale.US);
            if (page.contains("res=success") || page.contains("doonload(1")) {
                return Result.success("Le portail a accepté la connexion. Validation Internet en cours.");
            }
            return Result.failure("Le portail a refusé la connexion ou Internet reste indisponible.");
        } catch (Throwable throwable) {
            return Result.failure(friendlyError(throwable));
        }
    }

    private static boolean isOnline(RawHttpClient client) {
        try {
            RawHttpClient.Response response = client.execute("GET", CHECK_URL, null, null, 0);
            return response.statusCode == 204;
        } catch (Throwable ignored) {
            return false;
        }
    }

    private static void validatePortalUrl(String value, boolean logon) throws Exception {
        URL url = new URL(value);
        if (!"https".equalsIgnoreCase(url.getProtocol())) throw new SecurityException("Protocole inattendu");
        if (!PORTAL_HOST.equalsIgnoreCase(url.getHost())) throw new SecurityException("Hôte portail inattendu");
        String path = url.getPath() == null ? "" : url.getPath();
        if (logon) {
            if (!"/logon".equals(path) || url.getPort() != 3991) throw new SecurityException("Étape logon inattendue");
        } else {
            if (!path.endsWith("/intercept.php")) throw new SecurityException("Page portail inattendue");
        }
    }

    private static String friendlyError(Throwable throwable) {
        String name = throwable == null ? "" : throwable.getClass().getSimpleName();
        if (name.contains("UnknownHost")) return "Le DNS du Wi-Fi GCU ne répond pas encore. Nouvel essai automatique plus tard.";
        if (name.contains("Timeout") || name.contains("Connect")) return "Le portail GCU ne répond pas encore. Nouvel essai automatique plus tard.";
        if (name.contains("SSL") || name.contains("Certificate")) return "La vérification HTTPS du portail a échoué.";
        if (throwable instanceof SecurityException) return "Le portail détecté ne correspond pas au portail GCU attendu.";
        return "Échec temporaire de la connexion GCU (" + (name.isEmpty() ? "erreur réseau" : name) + ").";
    }

    static final class Result {
        final boolean success;
        final boolean waiting;
        final String message;

        private Result(boolean success, boolean waiting, String message) {
            this.success = success;
            this.waiting = waiting;
            this.message = message;
        }

        static Result success(String message) { return new Result(true, false, message); }
        static Result failure(String message) { return new Result(false, false, message); }
        static Result waiting(String message) { return new Result(false, true, message); }
    }
}
