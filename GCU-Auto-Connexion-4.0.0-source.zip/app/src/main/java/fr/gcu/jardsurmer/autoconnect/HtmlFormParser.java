package fr.gcu.jardsurmer.autoconnect;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class HtmlFormParser {
    private static final Pattern FORM_PATTERN = Pattern.compile("(?is)<form\\b([^>]*)>(.*?)</form\\s*>");
    private static final Pattern INPUT_PATTERN = Pattern.compile("(?is)<input\\b([^>]*)>");
    private static final Pattern BUTTON_PATTERN = Pattern.compile("(?is)<button\\b([^>]*)>(.*?)</button\\s*>");
    private static final Pattern ATTR_PATTERN = Pattern.compile("(?is)([a-zA-Z_:][-a-zA-Z0-9_:.]*)(?:\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+)))?");

    private HtmlFormParser() {}

    static Form parseBest(String pageUrl, String html) throws Exception {
        if (html == null) throw new IllegalArgumentException("Page HTML vide");
        Matcher forms = FORM_PATTERN.matcher(html);
        Form best = null;
        int bestScore = Integer.MIN_VALUE;
        while (forms.find()) {
            Map<String, String> attrs = attributes(forms.group(1));
            String inner = forms.group(2);
            Form form = new Form();
            form.pageUrl = pageUrl;
            form.method = value(attrs, "method", "GET").toUpperCase(Locale.US);
            form.action = new URI(pageUrl).resolve(htmlDecode(value(attrs, "action", pageUrl))).toString();

            Matcher inputs = INPUT_PATTERN.matcher(inner);
            while (inputs.find()) {
                Map<String, String> inputAttrs = attributes(inputs.group(1));
                Field field = new Field();
                field.type = value(inputAttrs, "type", "text").toLowerCase(Locale.US);
                field.name = htmlDecode(value(inputAttrs, "name", ""));
                field.id = htmlDecode(value(inputAttrs, "id", ""));
                field.value = htmlDecode(value(inputAttrs, "value", ""));
                field.checked = inputAttrs.containsKey("checked");
                field.disabled = inputAttrs.containsKey("disabled");
                if (!field.name.isEmpty()) form.fields.add(field);
            }

            Matcher buttons = BUTTON_PATTERN.matcher(inner);
            while (buttons.find()) {
                Map<String, String> buttonAttrs = attributes(buttons.group(1));
                Field field = new Field();
                field.type = value(buttonAttrs, "type", "submit").toLowerCase(Locale.US);
                field.name = htmlDecode(value(buttonAttrs, "name", ""));
                field.id = htmlDecode(value(buttonAttrs, "id", ""));
                field.value = htmlDecode(value(buttonAttrs, "value", stripTags(buttons.group(2)).trim()));
                field.disabled = buttonAttrs.containsKey("disabled");
                if (!field.name.isEmpty()) form.fields.add(field);
            }

            form.identifyCredentialFields();
            int score = form.score();
            if (score > bestScore) {
                bestScore = score;
                best = form;
            }
        }
        if (best == null) throw new IllegalArgumentException("Formulaire de connexion introuvable");
        return best;
    }

    private static Map<String, String> attributes(String raw) {
        LinkedHashMap<String, String> out = new LinkedHashMap<String, String>();
        Matcher matcher = ATTR_PATTERN.matcher(raw == null ? "" : raw);
        while (matcher.find()) {
            String key = matcher.group(1).toLowerCase(Locale.US);
            String val = matcher.group(2) != null ? matcher.group(2)
                    : matcher.group(3) != null ? matcher.group(3)
                    : matcher.group(4) != null ? matcher.group(4) : "";
            out.put(key, val);
        }
        return out;
    }

    private static String value(Map<String, String> map, String key, String fallback) {
        String value = map.get(key);
        return value == null ? fallback : value;
    }

    private static String stripTags(String value) {
        return value == null ? "" : value.replaceAll("(?is)<[^>]+>", " ");
    }

    private static String htmlDecode(String value) {
        if (value == null) return "";
        return value.replace("&amp;", "&")
                .replace("&#38;", "&")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&lt;", "<")
                .replace("&gt;", ">");
    }

    static final class Field {
        String type = "text";
        String name = "";
        String id = "";
        String value = "";
        boolean checked;
        boolean disabled;
    }

    static final class Form {
        String pageUrl;
        String action;
        String method;
        final List<Field> fields = new ArrayList<Field>();
        String usernameField;
        String passwordField;

        void identifyCredentialFields() {
            for (Field field : fields) {
                String key = (field.name + " " + field.id).toLowerCase(Locale.US);
                if (passwordField == null && ("password".equals(field.type)
                        || key.contains("password") || key.contains("passwd") || key.contains("pwd"))) {
                    passwordField = field.name;
                }
            }
            for (Field field : fields) {
                if (field.name.equals(passwordField)) continue;
                String key = (field.name + " " + field.id).toLowerCase(Locale.US);
                if (usernameField == null && (key.contains("username") || key.contains("user_name")
                        || key.equals("user") || key.contains("login") || key.contains("identifiant"))) {
                    usernameField = field.name;
                }
            }
            if (usernameField == null) {
                for (Field field : fields) {
                    if (("text".equals(field.type) || "email".equals(field.type)) && !field.name.isEmpty()) {
                        usernameField = field.name;
                        break;
                    }
                }
            }
        }

        int score() {
            int score = 0;
            if (passwordField != null) score += 100;
            if (usernameField != null) score += 60;
            if ("POST".equals(method)) score += 20;
            if (action != null && action.toLowerCase(Locale.US).contains("intercept.php")) score += 20;
            for (Field field : fields) {
                if ("challenge".equalsIgnoreCase(field.name)) score += 20;
            }
            return score;
        }

        byte[] buildBody(String username, String password) throws Exception {
            if (usernameField == null || passwordField == null) {
                throw new IllegalStateException("Champs d’identification non détectés");
            }
            LinkedHashMap<String, String> values = new LinkedHashMap<String, String>();
            boolean submitAdded = false;
            for (Field field : fields) {
                if (field.disabled || field.name.isEmpty()) continue;
                String type = field.type == null ? "" : field.type.toLowerCase(Locale.US);
                if (("checkbox".equals(type) || "radio".equals(type)) && !field.checked) continue;
                if ("reset".equals(type) || "file".equals(type)) continue;
                if ("submit".equals(type) || "button".equals(type)) {
                    if (submitAdded) continue;
                    submitAdded = true;
                }
                String value = field.value;
                if (field.name.equals(usernameField)) value = username;
                if (field.name.equals(passwordField)) value = password;
                values.put(field.name, value == null ? "" : value);
            }
            if (!values.containsKey(usernameField)) values.put(usernameField, username);
            if (!values.containsKey(passwordField)) values.put(passwordField, password);
            if (!values.containsKey("button")) values.put("button", "Authentification");

            StringBuilder encoded = new StringBuilder();
            for (Map.Entry<String, String> entry : values.entrySet()) {
                if (encoded.length() > 0) encoded.append('&');
                encoded.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                encoded.append('=');
                encoded.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }
            return encoded.toString().getBytes(StandardCharsets.UTF_8);
        }
    }
}
