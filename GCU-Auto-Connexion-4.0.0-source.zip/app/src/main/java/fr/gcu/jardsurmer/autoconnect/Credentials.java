package fr.gcu.jardsurmer.autoconnect;

final class Credentials {
    final String username;
    final String password;

    Credentials(String username, String password) {
        this.username = username == null ? "" : username;
        this.password = password == null ? "" : password;
    }

    boolean isComplete() {
        return !username.trim().isEmpty() && !password.isEmpty();
    }
}
