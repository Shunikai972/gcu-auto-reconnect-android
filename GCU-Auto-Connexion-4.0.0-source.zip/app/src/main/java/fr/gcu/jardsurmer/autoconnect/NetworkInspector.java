package fr.gcu.jardsurmer.autoconnect;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkAddress;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.RouteInfo;

import java.net.Inet4Address;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;

final class NetworkInspector {
    private NetworkInspector() {}

    static Network findWifiNetwork(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return null;
        Network active = cm.getActiveNetwork();
        if (isWifi(cm, active)) return active;
        for (Network network : cm.getAllNetworks()) {
            if (isWifi(cm, network)) return network;
        }
        return null;
    }

    private static boolean isWifi(ConnectivityManager cm, Network network) {
        if (network == null) return false;
        NetworkCapabilities caps = cm.getNetworkCapabilities(network);
        return caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
    }

    static boolean isGcuCandidate(Context context, Network network) {
        if (network == null) return false;
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return false;
        LinkProperties lp = cm.getLinkProperties(network);
        if (lp == null) return false;
        for (LinkAddress address : lp.getLinkAddresses()) {
            InetAddress inet = address.getAddress();
            if (inet instanceof Inet4Address) {
                String value = inet.getHostAddress();
                if (value != null && value.startsWith("192.168.182.")) return true;
            }
        }
        for (RouteInfo route : lp.getRoutes()) {
            InetAddress gateway = route.getGateway();
            if (gateway != null && "192.168.182.1".equals(gateway.getHostAddress())) return true;
        }
        return false;
    }

    static List<InetAddress> dnsServers(Context context, Network network) {
        ArrayList<InetAddress> result = new ArrayList<InetAddress>();
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm != null && network != null) {
            LinkProperties lp = cm.getLinkProperties(network);
            if (lp != null) result.addAll(lp.getDnsServers());
        }
        try {
            InetAddress fallback = InetAddress.getByName("192.168.182.1");
            if (!result.contains(fallback)) result.add(fallback);
        } catch (Throwable ignored) {}
        return result;
    }
}
