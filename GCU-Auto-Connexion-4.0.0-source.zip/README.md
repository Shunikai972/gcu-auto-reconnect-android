# GCU Auto Connexion 4.0.0

Application Android reconstruite à partir du rapport réel produit par Diagnostic ALCASAR GCU 3.

## Flux implémenté

1. Sélection du réseau Wi-Fi Android, même si la 4G reste le réseau actif du téléphone.
2. Vérification du sous-réseau `192.168.182.0/24`.
3. `GET http://192.168.182.1:3990/prelogin` pour obtenir un challenge neuf.
4. Résolution de `jard-sur-mer.gcuf.fr` sur le DNS du Wi-Fi.
5. Téléchargement HTTPS du formulaire `intercept.php` avec SNI et vérification du certificat.
6. Analyse des champs du formulaire puis POST de `challenge`, `userurl`, `username`, `password` et `button`.
7. Suivi de l'étape `https://jard-sur-mer.gcuf.fr:3991/logon`.
8. Contrôle final par `generate_204`.

## Comportement

- Bouton de connexion immédiate.
- Interrupteur d'auto-reconnexion.
- Nouvelle tentative lors de l'apparition du Wi-Fi et toutes les dix minutes.
- Service au premier plan avec notification persistante.
- Aucun envoi d'identifiants sur un Wi-Fi qui ne correspond pas au réseau GCU.
- Identifiants chiffrés avec Android Keystore AES/GCM.
- Absence de Wi-Fi traitée comme un état d'attente et non comme une erreur fatale.

## Compilation locale

Le script `build-local.sh` attend les variables suivantes :

- `ANDROID_JAR`
- `AAPT2`
- `R8_JAR`
- `ZIPALIGN`
- `APKSIGNER_JAR`

Il génère un certificat local neuf. Ne publiez jamais le fichier de clé produit par le script.
